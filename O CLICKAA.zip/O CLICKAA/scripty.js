

let money = 0;
let mpc = 1;       
let pinc = 0;
let path ="none";

const upgrades = [

    {
     name: "beer mugs",
     level: 0,
    baseCost: 10,
    multiplier: 1.15,
    apply() { mpc += 1; }
    },

    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    },
    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    },
    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    },
    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    },
    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    },
    {
        name: "sofa",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    }
];

const illegalUpgrades = [ 
     {
        name: "ANINFESTATIOOOOON",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    }
 ];


const legalUpgrades = [ 
     {
        name: "AAAAAAAAAAAAAAAAAAAAAAAAAH",
        level: 0,
        baseCost: 20,
        multiplier: 1.75,
        apply() { mpc += 1; }
    }
];






function getCost(upgrade) {
  return Math.floor(upgrade.baseCost * Math.pow(upgrade.multiplier, upgrade.level));
}


function makeDrink() {
  money += mpc;
  updateUI();
}


function buyUpgrade(index) {
  let upgrade = upgrades[index];
  let cost = getCost(upgrade);

  if (money >= cost) {
    money -= cost;
    upgrade.level++;
    upgrade.apply();
    updateUI();

    if (path === "none" && allBought(upgrades)) {
      document.getElementById("offer").style.display = "block";
    }
  }
}

function updateUI() {
  document.getElementById("money").textContent = money;

  for (let i = 0; i < upgrades.length; i++) {
    let u = upgrades[i];
    document.getElementById("upgradeBtn" + i).textContent =
      u.name + " (Lv " + u.level + ") - Cost: " + getCost(u);
  }
}

function allBought(list) {
  for (let i = 0; i < list.length; i++) {
    if (list[i].level === 0) {
      return false;   
    }
  }
  return true;        
}

function choose(answer) {
  path = answer;
  document.getElementById("offer").style.display = "none";

  if (answer === "illegal") {
    upgrades.push(...illegalUpgrades);
  } else {
    upgrades.push(...legalUpgrades);
  }

  renderShop();
  updateUI();
}

function renderShop() {
  const shop = document.getElementById("theups");
  shop.innerHTML = "";

  for (let i = 0; i < upgrades.length; i++) {
    const btn = document.createElement("button");
    btn.id = "upgradeBtn" + i;
    btn.onclick = function () { buyUpgrade(i); };
    shop.appendChild(btn);
  }
}

updateUI();